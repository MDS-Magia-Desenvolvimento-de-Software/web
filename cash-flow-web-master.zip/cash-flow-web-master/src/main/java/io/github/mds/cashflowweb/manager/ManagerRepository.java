package io.github.mds.cashflowweb.manager;

import io.github.mds.cashflowweb.user.UserRepository;

public interface ManagerRepository extends UserRepository<Manager> {

}
