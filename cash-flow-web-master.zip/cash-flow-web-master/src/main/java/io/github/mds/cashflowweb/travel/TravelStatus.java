package io.github.mds.cashflowweb.travel;

public enum TravelStatus {

    SCHEDULED,
    IN_PROGRESS,
    FINALIZED
}
