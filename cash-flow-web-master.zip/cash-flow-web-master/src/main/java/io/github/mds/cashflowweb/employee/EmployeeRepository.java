package io.github.mds.cashflowweb.employee;

import io.github.mds.cashflowweb.user.UserRepository;

public interface EmployeeRepository extends UserRepository<Employee> {

}
